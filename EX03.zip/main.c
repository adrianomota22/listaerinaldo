//3. Crie uma função que receba três lados de um triângulo e verifique se esses lados
//formam um triângulo válido. Um triângulo é válido se a soma de dois de seus lados
//for sempre maior que o terceiro. Caso o triângulo seja válido, a função deverá
//retornar 1. Caso contrário, não deve retornar nada. 

#include <stdio.h>

int main(void) {

int a, b, c; 

printf("informe o lado A do triangulo:");
 scanf("%d", &a);
printf("informe o lado B do tringulo:");
 scanf("%d", &b);
printf("informe o lado C do triangulo:");
 scanf("%d", &c);
  
if ((a + b > c) && (a + c > b) && (b + c > a)) {
  printf("1\n");
}  
return 0;
}  
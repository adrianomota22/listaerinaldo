//7. Desenvolva uma função que receba um número inteiro e determine se ele é par
//ou ímpar. Exiba uma mensagem correspondente para cada caso.


#include <stdio.h>

int main(void) {
int n;

printf("informe um numero inteiro:");
 scanf("%d", &n);

if (n %2 == 0) 
 printf("numero par.");
else
 printf("numero impar.");  

return 0;
}  
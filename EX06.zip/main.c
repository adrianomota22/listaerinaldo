//6. Elabore uma função que receba a nota de um aluno (de 0 a 10) e classifique se
//ele foi aprovado ou reprovado. A aprovação ocorre se a nota for 7 ou superior, e
//reprovação caso contrário. A função deve exibir mensagens para os dois casos.
//


#include <stdio.h>

int main(void) {
int nota;

 printf("informe sua nota de 0 a 10:");
  scanf("%d", &nota);

 if (nota<=6) { 
   printf("Reprovado.");
 } 
 if (nota>=7) {
   printf("Aprovado.");
 }    
return 0;
}  
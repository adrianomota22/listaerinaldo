//13. Crie um programa que simule uma calculadora simples. O programa deve
//permitir ao usuário escolher entre quatro operações aritméticas: soma, subtração,
//multiplicação e divisão. O usuário deve informar a operação desejada e dois
//números. O programa deve realizar a operação selecionada e exibir o resultado.
//Caso a operação não seja reconhecida, o programa deve informar um erro

#include <stdio.h>

int main() {
    char operacao;
    float num1, num2, resultado;

  
    printf("Escolha a operação desejada:\n");
    printf(" + para soma\n");
    printf(" - para subtração\n");
    printf(" * para multiplicação\n");
    printf(" / para divisão\n");
    printf("Digite a operação: ");
    scanf(" %c", &operacao);

    printf("Digite o primeiro número: ");
    scanf("%f", &num1);
    printf("Digite o segundo número: ");
    scanf("%f", &num2);

    switch (operacao) {
     case '+':
      resultado = num1 + num2;
    printf("Resultado da soma: %.2f\n", resultado);
    break;
     case '-':
      resultado = num1 - num2;
      printf("Resultado da subtração: %.2f\n", resultado);
    break;
     case '*':
      resultado = num1 * num2;
    printf("Resultado da multiplicação: %.2f\n", resultado);
    break;
     case '/':
          
    if (num2 != 0) {
      resultado = num1 / num2;
      printf("Resultado da divisão: %.2f\n", resultado);
    } else {
      printf("Erro: Divisão por zero não é permitida.\n");
    }
      break;
      default:
      
      printf("Erro: Operação inválida.\n");
      break;
    }

    return 0;
}

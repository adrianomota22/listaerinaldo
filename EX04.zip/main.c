//4. Elabore uma função que receba três lados de um triângulo e verifique se ele é um
//triângulo retângulo. Um triângulo é retângulo se o quadrado da hipotenusa (o maior
//lado) for igual à soma dos quadrados dos outros dois lados. Caso o triângulo seja
//retângulo, a função deverá informar ao usuário que o triângulo é retângulo, caso
//contrário, não deverá fazer nada.

#include <stdio.h>

int main(void) {

  int a, b, c, lado1, lado2, maior;

 printf("inofrme o lado A do triangulo:");
  scanf("%d", &a);
 printf("informe o lado B do triangulo:");
  scanf("%d", &b);
 printf("informe p lado C do tringulo:");
  scanf("%d", &c);

 if (a>=b && a>=c) {
   maior = a;
   lado1 = b;
   lado2 = c;
 } else if (b>=a && b>=c) {
  maior = b;
  lado1 = a;
  lado2 = c;
  } else 
  maior = c;
  lado1 = a;
  lado2 = b;

  if (maior * maior ==(lado1 * lado1 + lado2 * lado2));
   printf("O triangulo é retangulo\n");
return 0;
}  
//11. Crie uma função que receba o valor de um produto e calcule o valor do desconto
//de ICMS com base nas faixas de preço do produto:
//● Até R$ 1.000,00: Desconto de 5%
//● De R$ 1.000,01 até R$ 5.000,00: Desconto de 10%
//● Acima de R$ 5.000,00: Desconto de 15%
//Use a estrutura condicional aninhada para aplicar o desconto corretamente

#include <stdio.h> {

  float vp, desconto;

  printf("informe o valor do produto:");
   scanf("%f", &vp);

  if (vp <= 1000) {
    descnto = vp * 0.05;
  }
  else if (vp<= 5000) {
    desconto = vp´* 0.10;
  }
  else (vp>5000) {
    desconto = vp * 0,15;
  }
  printf("valor do produto com desconto é", desconto);
  
return 0;
}  
//1. Crie uma função que receba um número inteiro de 1 a 10 e retorne 1 se o número
//for primo. Caso contrário, não retorne nada. Você não pode usar laços de repetição,
//por essa razão, limite a verificação a um conjunto pequeno de números para
//verificar se são primos. Um número primo é divisível apenas por 1 e por ele mesmo
#include <stdio.h>

int main(void) {
  
  int n;

 printf("informe um numero de 1 a 10:");
  scanf("%d", &n);

 if (n == 2) {
  printf("1\n");
 } 
 else if (n == 3) {
  printf("1\n");
 } 
 else if (n == 5) {
  printf("1\n");
 } 
 else if (n == 7) {
  printf("1\n");
 } else {
 }

return 0;
}
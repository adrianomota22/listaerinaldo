//14. Elabore um programa que exiba uma mensagem de boas-vindas baseada no
// do dia. O usuário deve informar o turno usando um número (1 para manhã, 2
//para tarde, 3 para noite). O programa deve exibir uma mensagem apropriada para
//cada turno e um erro para entradas inválidas. 

#include <stdio.h>

int main() {

int turno;
  
printf("selecione algum turno\n");
printf("1 manha\n");
printf("2 tarde\n");
printf("3 noite\n");
printf("informe o turno:\n");
 scanf("%d", &turno); 

 switch (turno) {
   case 1:
    printf("BOM DIA, Seja Bem Vindo.");
   break;
   case 2:
   printf("BOA TARDE, Seja Bem vindo.");
   break;
   case 3:
   printf("BOA NOITE, Seja Bem Vindo.");
   break;
     default:
    printf("turno invalido, informe 1, 2, 3.\n");
   break;
  } 
    return 0;
}
